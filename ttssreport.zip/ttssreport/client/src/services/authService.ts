import { API_BASE_URL } from '@/config';

export interface User {
  id: number;
  phone?: string;
  wechat_openid?: string;
  username?: string;
  role: string;
  status: string;
}

export interface AuthResponse {
  success: boolean;
  token: string;
  user: User;
  message?: string;
}

export const authService = {
  async login(username: string, password: string): Promise<AuthResponse> {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    
    if (!response.ok) {
      throw new Error('登录失败');
    }
    
    return response.json();
  },

  async me(): Promise<User | null> {
    const token = localStorage.getItem('token');
    if (!token) {
      return null;
    }

    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` },
      credentials: 'include',
    });
    
    if (!response.ok) {
      localStorage.removeItem('token');
      return null;
    }
    
    return response.json();
  },

  async logout(): Promise<{ success: boolean }> {
    localStorage.removeItem('token');
    const response = await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('退出登录失败');
    }
    
    return response.json();
  },
};
