import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import b1SignalRoutes from './routes/b1SignalRoutes.js';

// 加载环境变量
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());

// 路由
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/b1-signal', b1SignalRoutes);

// 健康检查
app.get('/health', (req, res) => {
  res.json({ success: true, message: 'Server is running' });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});