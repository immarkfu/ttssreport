import express from 'express';
import { authenticateToken } from '../middleware/authMiddleware.js';
import {
  getResults,
  filterAndTag,
  getStockDetail,
  getLatestTradeDate,
} from '../controllers/b1SignalController.js';

const router = express.Router();

router.get('/results', authenticateToken, getResults);
router.post('/filter-and-tag', authenticateToken, filterAndTag);
router.get('/stock-detail', authenticateToken, getStockDetail);
router.get('/latest-trade', authenticateToken, getLatestTradeDate);

export default router;